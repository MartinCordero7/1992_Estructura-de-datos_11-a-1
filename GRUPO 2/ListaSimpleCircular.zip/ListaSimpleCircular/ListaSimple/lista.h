#ifndef LISTA_H
#define LISTA_H

#include <iostream>
using namespace std;

// Forward declare Ordenamiento
template <typename T> class Ordenamiento;

template <typename T>
class Nodo {
public:
    T data;
    Nodo* siguiente;
    Nodo(T data) : data(data), siguiente(nullptr) {}
};

template <typename T>
class Lista {
private:
    Nodo<T>* cabeza;
    void copiarLista(const Nodo<T>* otraCabeza);

public:
    friend class Ordenamiento<T>;

    Lista();  // Constructor
    ~Lista(); // Destructor
    Lista(const Lista& otra); // Constructor copia
    Lista& operator=(const Lista& otra); // Operador de asignación

    void insertarPorCabeza(T data); // Inserción al inicio
    void insertarPorCola(T data);  // Inserción al final
    void eliminarPorCabeza();      // Eliminación del inicio
    void eliminarPorCedula(string cedula); // Eliminación por cédula
    void mostrarLista() const;     // Mostrar lista completa
    void eliminarCaracter(char c); // Eliminar un carácter específico en los datos
    void reemplazarCaracter(char original, char reemplazo); // Reemplazar un carácter
    void buscarPorCedula(string cedula); // Buscar un nodo por cédula
};

#endif
