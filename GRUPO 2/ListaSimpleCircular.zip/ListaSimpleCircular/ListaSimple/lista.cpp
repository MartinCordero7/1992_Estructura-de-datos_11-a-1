#include "lista.h"
#include <iostream>
#include <algorithm>
using namespace std;

template <typename T>
Lista<T>::Lista() : cabeza(nullptr) {}

template <typename T>
Lista<T>::~Lista() {
    while (cabeza != nullptr) {
        eliminarPorCabeza();
    }
}

template <typename T>
void Lista<T>::insertarPorCabeza(T data) {
    Nodo<T>* nuevo = new Nodo<T>(data);

    if (!cabeza) {
        // Lista vacía: el nodo apunta a sí mismo
        cabeza = nuevo;
        nuevo->siguiente = cabeza;
    } else {
        // Encontrar el último nodo
        Nodo<T>* temp = cabeza;
        while (temp->siguiente != cabeza) {
            temp = temp->siguiente;
        }
        nuevo->siguiente = cabeza;
        cabeza = nuevo;
        temp->siguiente = cabeza;  // Mantener el ciclo
    }
}

template <typename T>
void Lista<T>::insertarPorCola(T data) {
    Nodo<T>* nuevo = new Nodo<T>(data);

    if (!cabeza) {
        // Lista vacía: el nodo apunta a sí mismo
        cabeza = nuevo;
        nuevo->siguiente = cabeza;
    } else {
        // Encontrar el último nodo
        Nodo<T>* temp = cabeza;
        while (temp->siguiente != cabeza) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevo;
        nuevo->siguiente = cabeza;  // Mantener el ciclo
    }
}

template <typename T>
void Lista<T>::eliminarPorCabeza() {
    if (!cabeza) return;

    if (cabeza->siguiente == cabeza) {
        // Solo hay un nodo
        delete cabeza;
        cabeza = nullptr;
    } else {
        // Encontrar el último nodo
        Nodo<T>* temp = cabeza;
        while (temp->siguiente != cabeza) {
            temp = temp->siguiente;
        }
        Nodo<T>* aEliminar = cabeza;
        cabeza = cabeza->siguiente;
        temp->siguiente = cabeza;  // Mantener el ciclo
        delete aEliminar;
    }
}

template<typename T>
void Lista<T>::eliminarPorCedula(string cedula) {
    if (!cabeza) {
        cout << "La lista está vacía" << endl;
        return;
    }

    Nodo<T>* actual = cabeza;
    Nodo<T>* anterior = nullptr;

    do {
        if (actual->data.getCedula() == cedula) {
            if (anterior == nullptr) {
                // Eliminar cabeza
                eliminarPorCabeza();
            } else {
                anterior->siguiente = actual->siguiente;
                if (actual == cabeza) {
                    cabeza = actual->siguiente;  // Actualizar cabeza si es necesario
                }
                delete actual;
            }
            cout << "Persona con cédula " << cedula << " eliminada exitosamente" << endl;
            return;
        }
        anterior = actual;
        actual = actual->siguiente;
    } while (actual != cabeza);

    cout << "No se encontró ninguna persona con la cédula " << cedula << endl;
}

template<typename T>
void Lista<T>::buscarPorCedula(string cedula) {
    if (!cabeza) {
        cout << "La lista está vacía" << endl;
        return;
    }

    Nodo<T>* actual = cabeza;
    do {
        if (actual->data.getCedula() == cedula) {
            cout << "Persona encontrada:" << endl;
            cout << "Cédula: " << actual->data.getCedula() << endl;
            cout << "Nombre: " << actual->data.getNombre() << endl;
            cout << "Apellido: " << actual->data.getApellido() << endl;
            return;
        }
        actual = actual->siguiente;
    } while (actual != cabeza);

    cout << "No se encontró ninguna persona con la cédula " << cedula << endl;
}

template <typename T>
void Lista<T>::mostrarLista() const {
    if (!cabeza) {
        cout << "La lista está vacía" << endl;
        return;
    }

    Nodo<T>* actual = cabeza;
    do {
        cout << actual->data.getCedula() << " "
             << actual->data.getApellido() << " "
             << actual->data.getNombre() << endl;
        actual = actual->siguiente;
    } while (actual != cabeza);
}

template <typename T>
Lista<T>::Lista(const Lista& otra) : cabeza(nullptr) {
    copiarLista(otra.cabeza);
}

template <typename T>
Lista<T>& Lista<T>::operator=(const Lista& otra) {
    if (this != &otra) {
        while (cabeza != nullptr) {
            eliminarPorCabeza();
        }
        copiarLista(otra.cabeza);
    }
    return *this;
}

template <typename T>
void Lista<T>::copiarLista(const Nodo<T>* otraCabeza) {
    const Nodo<T>* actual = otraCabeza;
    if (!actual) return;

    do {
        insertarPorCola(actual->data);
        actual = actual->siguiente;
    } while (actual != otraCabeza);
}

template <typename T>
void Lista<T>::reemplazarCaracter(char original, char reemplazo) {
    Nodo<T>* actual = cabeza;
    if (!actual) return;

    do {
        string cedula = actual->data.getCedula();
        replace(cedula.begin(), cedula.end(), original, reemplazo);
        actual->data.setCedula(cedula);

        string apellido = actual->data.getApellido();
        replace(apellido.begin(), apellido.end(), original, reemplazo);
        actual->data.setApellido(apellido);

        string nombre = actual->data.getNombre();
        replace(nombre.begin(), nombre.end(), original, reemplazo);
        actual->data.setNombre(nombre);

        actual = actual->siguiente;
    } while (actual != cabeza);
}

#include "persona.h"
template class Lista<Persona>;
