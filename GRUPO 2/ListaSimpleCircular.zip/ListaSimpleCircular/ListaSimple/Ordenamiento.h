#ifndef ORDENAMIENTO_H
#define ORDENAMIENTO_H

#include <iostream>

// Forward declaration
template <typename T> class Lista;
template <typename T> class Nodo;

template <typename T>
class Ordenamiento {
public:
    // Función de ordenamiento por inserción
    static void insertionSort(Lista<T>& lista) {
        if (lista.cabeza == nullptr || lista.cabeza->siguiente == lista.cabeza) {
            // Lista vacía o con un solo elemento, ya está ordenada
            return;
        }

        Nodo<T>* listaOrdenada = nullptr;  // Nueva lista ordenada (temporal)
        Nodo<T>* actual = lista.cabeza;
        Nodo<T>* inicio = lista.cabeza;

        do {
            Nodo<T>* siguiente = actual->siguiente;

            // Insertar el nodo actual en la nueva lista ordenada
            if (listaOrdenada == nullptr || listaOrdenada->data.getCedula() >= actual->data.getCedula()) {
                actual->siguiente = listaOrdenada ? listaOrdenada : actual;
                listaOrdenada = actual;
            } else {
                Nodo<T>* temp = listaOrdenada;
                while (temp->siguiente != nullptr && 
                       temp->siguiente->data.getCedula() < actual->data.getCedula()) {
                    temp = temp->siguiente;
                }
                actual->siguiente = temp->siguiente;
                temp->siguiente = actual;
            }

            actual = siguiente;
        } while (actual != inicio);

        // Ajustar la cabeza para que apunte al inicio de la lista ordenada
        lista.cabeza = listaOrdenada;

        // Mantener la circularidad: Encontrar el último nodo y conectarlo a la cabeza
        Nodo<T>* temp = lista.cabeza;
        while (temp->siguiente != nullptr && temp->siguiente != lista.cabeza) {
            temp = temp->siguiente;
        }
        temp->siguiente = lista.cabeza;  // Reconectar el último nodo con la cabeza
    }

    // Mostrar la lista ordenada
    static void mostrarListaOrdenada(const Lista<T>& lista) {
        if (lista.cabeza == nullptr) {
            std::cout << "La lista está vacía.\n";
            return;
        }

        std::cout << "\nLista ordenada por cédula:\n";
        Nodo<T>* actual = lista.cabeza;
        do {
            std::cout << actual->data.getCedula() << " "
                      << actual->data.getApellido() << " "
                      << actual->data.getNombre() << std::endl;
            actual = actual->siguiente;
        } while (actual != lista.cabeza);
    }
};

#endif
