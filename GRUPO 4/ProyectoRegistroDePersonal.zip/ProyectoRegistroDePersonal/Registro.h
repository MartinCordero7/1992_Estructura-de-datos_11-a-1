#if !defined(__Registro_Personal_Registro_h)
#define __Registro_Personal_Registro_h

#include "Fecha.h"

class Registro {
public:
protected:
private:
   char* dni;
   Fecha fecha;
};

#endif