#include <iostream>
#include "Menus.h"

int main() {
    Menus menus(13);
    menus.operarMenu();    
    return 0;
}
